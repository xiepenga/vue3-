/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */

 console.log("hello world")

 function test(){
     console.log("test")
 }

 test()
 console.log(document)