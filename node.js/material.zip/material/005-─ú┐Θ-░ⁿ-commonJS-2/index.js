/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */
var moduleA = require('./a')
var moduleB = require('./b')
var moduleC = require('./c')

console.log(moduleA)
// console.log(moduleA.upper("kerwin"))
moduleA.test()
moduleB()
moduleC()
