/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */
function test(){
    console.log("test-ccc")
}
module.exports = test