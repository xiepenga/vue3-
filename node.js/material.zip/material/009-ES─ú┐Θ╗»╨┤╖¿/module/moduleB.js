/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */
const moduleB = {
    getName(){
        return "moduleB"
    }
}

export {
    moduleB
}