/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */
const moduleA = {
    getName(){
        return "moduleAAAAAAA"
    }
}

export default moduleA