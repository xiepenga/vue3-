/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */
import moduleA from './module/moduleA.js'
import {moduleB} from './module/moduleB.js'
// const moduleA = require("./module/moduleA.js")

console.log(moduleA.getName())

console.log(moduleB.getName())